#!/usr/bin/python
import os
import sys
import glob
import math
import requests
import json
import random
import urllib2
import time
from PIL import Image
import imagehash

if __name__ == '__main__':
    for line in sys.stdin:
        sep = line.strip().split("\t")
        if len(sep) < 6:
            continue
        musical_id = sep[0]
        like_cnt = sep[1]
        user_id = sep[2]
        fan_cnt = sep[3]
        create_time = sep[4]
        thumbnail_uri = sep[5]
        random_name = thumbnail_uri.split('/')[-1]
        grep_sep = thumbnail_uri.split("reg02/")
        if len(grep_sep) != 2:
            continue
        image_url = "http://musically.muscdn.com/reg02/" + grep_sep[1]
        image_path = "/tmp/"+random_name
        try:
            r = urllib2.Request(image_url)
            data_open = urllib2.urlopen(r, None, 1)
            data = data_open.read()
            f = open(image_path, "wb")
            f.write(data)
            f.close()
            phash_id = int(str(imagehash.phash(Image.open(image_path))), 16)
            dhash_id = int(str(imagehash.dhash(Image.open(image_path))), 16)
            os.remove(image_path)
            output = [musical_id, like_cnt, user_id, fan_cnt, create_time, str(phash_id), str(dhash_id)]
            print '\t'.join(output)
        except Exception, e:
            continue
